package com.restapi.googleAPI;

public class resources {

	//You can call method from the class name with className.method if that method is defined with static
	public static String getSearchPlaces()
	{
		
		String res="/maps/api/place/nearbysearch/json";
		return res;
	}
	
	public static String getPlaceDetails()
	{
		
		String res="/maps/api/place/details/json";
		return res;
	}
	
	public static String getNearBySearchPlaces()
	{
		
		String res="/maps/api/place/nearbysearch/json";
		return res;
	}
	


}
