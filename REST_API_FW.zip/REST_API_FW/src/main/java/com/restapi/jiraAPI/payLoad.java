package com.restapi.jiraAPI;

public class payLoad {

	public static String createNewIssue(int randomNumber)
	{
	
		String b ="{" + 
				"    \"fields\": {" + 
				"        \"project\": {" + 
				"            \"key\": \"MYP\"" + 
				"        },\r\n" + 
				"        \"summary\": \"Create new issue - "+randomNumber+"\""+"," + 
				"        \"issuetype\": {" + 
				"            \"name\": \"Bug\"" + 
				"        }," + 
				"        \"description\": \"Creating an issue using project keys and issue type names using REST API\"" + 
				"    }" + 
				"}";
		
		
		return b;
	}
	public static String addCommentInIssue()
	{
	
		String b ="{" + 
				"  \"body\": \"Inserting first comment\"," + 
				"  \"visibility\": {" + 
				"    \"type\": \"role\"," + 
				"    \"value\": \"Administrators\"" + 
				"  }" + 
				"}'";
		
		return b;
	}
	public static String updateCommentInIssue()
	{
	
		String b ="{" + 
				"  \"body\": \"Updating test comment\"," + 
				"  \"visibility\": {" + 
				"    \"type\": \"role\"," + 
				"    \"value\": \"Administrators\"" + 
				"  }" + 
				"}'";
		
		return b;
	}
	
}
