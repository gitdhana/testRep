package com.restapi.jiraAPI;

public class resources {

	public static String postCreateNewIssue()
	{		
		String res="/rest/api/2/issue";
		return res;
	}
	
	public static String postAddingCommentInIssue(String issueID)
	{		
		String res="/rest/api/2/issue/"+issueID+"/comment";
		return res;
	}
	
	public static String postUpdatingCommentInIssue(String issueID, String commentID)
	{		
		String res="/rest/api/2/issue/"+issueID+"/comment/"+commentID;
		return res;
	}
	
	
	


}
