package com.restapi.twitterAPI;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class resources {
	private static Logger log =LogManager.getLogger(resources.class.getName());

	public static String getLatestTweet()
	{		
		String res="/home_timeline.json";
		return res;
	}
	
	public static String postCreateTweet()
	{		
		String res="/update.json";
		return res;
	}
	

}
