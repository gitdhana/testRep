package com.restapi.utilities;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.Random;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class Utilities {
	
	public static XmlPath rawToXML(Response r)
	{
		
		String respon=r.asString();
		XmlPath x=new XmlPath(respon);
		return x;
		
	}
	
	public static JsonPath rawToJSON(Response r)
	{ 
		String respon=r.asString();
		JsonPath x=new JsonPath(respon);
		return x;
	}
	
	public static String GenerateStringFromResource(String path) throws IOException {

	    return new String(Files.readAllBytes(Paths.get(path)));

	}
	
	public static int generateRandomNumber() 
    { 
        // create instance of Random class 
        Random rand = new Random(); 
  
        // Generate random integers in range 0 to 99999 
        int randNum = rand.nextInt(100000); 
        return randNum;
    } 
	
	public static String getSessionKEY() throws IOException
	{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("D:\\Automation\\Selenium_Projects_Updated\\REST_API_Automation\\src\\Files\\env.properties");
		prop.load(fis);		
		RestAssured.baseURI=prop.getProperty("HOST_JIRA");
		
		Response res = given()
				.header("Content-Type","application/json")
				.body("{ \"username\": \"dehury.dhananjaya\", \"password\": \"Lulu#6391\" }")
			.when()
				.post("/rest/auth/1/session")
			.then()
				.statusCode(200)
			.extract().response();
			
			JsonPath js = Utilities.rawToJSON(res);
			String sessionid = js.get("session.value");
			return sessionid;
	}

}
