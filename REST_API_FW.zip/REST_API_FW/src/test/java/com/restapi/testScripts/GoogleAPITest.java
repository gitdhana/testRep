package com.restapi.testScripts;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static org.hamcrest.Matchers.equalTo;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.restapi.googleAPI.resources;
import com.restapi.utilities.Utilities;



public class GoogleAPITest {

	private static Logger log =LogManager.getLogger(GoogleAPITest.class.getName());
	Properties prop = new Properties();
	
	@BeforeClass
	public void GetData() throws IOException
	{
		
		FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"//src//main//java//com//restapi//resources//env.properties");;
		prop.load(fis);
		log.info("Host information : "+prop.getProperty("HOST"));
		RestAssured.baseURI=prop.getProperty("HOST");
	}
	
	
	// Search Near By places in using Google API
	@Test
	public void SearchPlaces()
	{
//		RestAssured.baseURI="https://maps.googleapis.com";
		try
		{
			given().
				param("location","-33.8670522,151.1957362").
				param("radius","500").
				param("key",prop.getProperty("KEY")).
			when().
				get(resources.getSearchPlaces()).
			then().
				assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
				body("results[0].name",equalTo("Sydney")).and().
				body("results[0].place_id", equalTo("ChIJP3Sa8ziYEmsRUKgyFmh9AQM")).and().
				header("Server","scaffolding on HTTPServer2");
		}
		catch(Exception e)
		{
			e.printStackTrace();
//			log.error("FAILED with Error : ",e);
		}
		log.info("Test Passed");
	}
		
	// Place Details using Google API
	@Test
	public void PlaceDetails()
	{
		try
		{
			given().
				param("placeid", "ChIJq6qq6jauEmsR46KYci7M5Jc").
				param("key", prop.getProperty("KEY")).
			when().
				get(resources.getPlaceDetails()).
			then().
				assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
				body("result.name", equalTo("Astral Residences at The Star")).and().
				body("result.place_id", equalTo("ChIJq6qq6jauEmsR46KYci7M5Jc")).and().
				header("Server","scaffolding on HTTPServer2");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	//Print all the results from the JSON response
	@Test
	public void PrintAllSearchResults()
	{
		try
		{
			Response res = given().
				param("location","-33.8670522,151.1957362").
				param("radius","500").
				param("key",prop.getProperty("KEY")).log().all().
			when().
				get(resources.getNearBySearchPlaces()).
			then().
				assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
				extract().response();
			
			JsonPath jsonRes = Utilities.rawToJSON(res);
			int count =jsonRes.get("results.size()");
			log.info(count);
			System.out.println(count);
			for(int i=0;i<count;i++)
			{
				String js = jsonRes.get("results["+ i +"].name");
				System.out.println(js);
				//log.info(js);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

}
