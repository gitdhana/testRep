package com.restapi.testScripts;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.restapi.jiraAPI.payLoad;
import com.restapi.jiraAPI.resources;
import com.restapi.utilities.Utilities;

//import Files.ReusableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class JiraAPITest {
	
	private static Logger log =LogManager.getLogger(JiraAPITest.class.getName());
	Properties prop = new Properties();
	
	@BeforeClass
	public void GetData() throws IOException
	{
		
		FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"//src//main//java//com//restapi//resources//env.properties");;
		prop.load(fis);
		log.info("Host information : "+prop.getProperty("HOST_JIRA"));
		RestAssured.baseURI=prop.getProperty("HOST_JIRA");
	}

	@Test
	public void createNewIssue_JIRA() throws IOException
	{
		//String str = Integer.toString(ReusableMethods.generateRandomNumber());
		Response res = given()
				.header("Content-Type","application/json")
				.header("Cookie","JSESSIONID="+Utilities.getSessionKEY())
				.body(payLoad.createNewIssue(Utilities.generateRandomNumber()))
			.when()
				.post(resources.postCreateNewIssue())
			.then()
				.statusCode(201)
			.extract().response();
//		String response = res.asString();
//		System.out.println(response);
		JsonPath js = Utilities.rawToJSON(res);
		String id = js.get("id");
		System.out.println(id);
	}
	
	@Test
	public void addCommentInIssue_JIRA() throws IOException
	{
		//String rand = Integer.toString(ReusableMethods.generateRandomNumber());
		// Create an issue 
		Response res = given()
				.header("Content-Type","application/json")
				.header("Cookie","JSESSIONID="+Utilities.getSessionKEY())
				.body(payLoad.createNewIssue(Utilities.generateRandomNumber()))
			.when()
				.post(resources.postCreateNewIssue())
			.then()
				.statusCode(201)
			.extract().response();
		
		JsonPath js = Utilities.rawToJSON(res);
		String id = js.get("id");
		System.out.println(id);
		
		//Adding Comment
			given()
				.header("Content-Type","application/json")
				.header("Cookie","JSESSIONID="+Utilities.getSessionKEY())
				.body(payLoad.addCommentInIssue())
			.when()
				.post(resources.postAddingCommentInIssue(id))
			.then()
				.statusCode(201);
	}

	@Test
	public void updateCommentInIssue_JIRA() throws IOException
	{
		//String rand = Integer.toString(ReusableMethods.generateRandomNumber());
		// Create an issue 
		Response res = given()
				.header("Content-Type","application/json")
				.header("Cookie","JSESSIONID="+Utilities.getSessionKEY())
				.body(payLoad.createNewIssue(Utilities.generateRandomNumber()))
			.when()
				.post(resources.postCreateNewIssue())
			.then()
				.statusCode(201)
			.extract().response();
		
		JsonPath js = Utilities.rawToJSON(res);
		String issueID = js.get("id");
		System.out.println(issueID);
		
		//Adding Comment
			
		Response resComment = 
			given()
				.header("Content-Type","application/json")
				.header("Cookie","JSESSIONID="+Utilities.getSessionKEY())
				.body(payLoad.addCommentInIssue())
			.when()
				.post(resources.postAddingCommentInIssue(issueID))
			.then()
				.statusCode(201)
			.extract().response();
			
			JsonPath js1 = Utilities.rawToJSON(resComment);
			String commentID = js1.get("id");
			
		// Updating Comment
			given()
			.header("Content-Type","application/json")
			.header("Cookie","JSESSIONID="+Utilities.getSessionKEY())
			.body(payLoad.updateCommentInIssue())
		.when()
			.put(resources.postUpdatingCommentInIssue(issueID, commentID))
		.then()
			.statusCode(200);
			
	}
	
	

}
