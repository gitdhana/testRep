package com.restapi.testScripts;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.restapi.twitterAPI.payLoad;
import com.restapi.twitterAPI.resources;
import com.restapi.utilities.Utilities;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

//https://mvnrepository.com/artifact/com.github.scribejava/scribejava-apis/2.5.3
//https://mvnrepository.com/artifact/com.github.scribejava/scribejava-core/2.5.3

public class TwitterAPITest {
	
	private static Logger log =LogManager.getLogger(TwitterAPITest.class.getName());
	Properties prop = new Properties();

	String ConsumerKey = "HyDUpaKjCurQpYmDeLJTaSdUS";
	String ConsumerSecret = "142Dgk7LAYgcAsS7AEQHps2eQhs7imcaea1YN5EvBxsifETfDO";
	String Token = "1079473715706916864-U5CrLTgN1dcE19HRoZL3xFHwtXAX35";
	String TokenSecret = "ZUrcwfcDxskOyJ7wMr8wNm5KQ4GefSBslDe752KfYeMtu";
	
	/*@BeforeClass
	public void GetData() throws IOException
	{
		
		FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"//src//main//java//com//restapi//resources//env.properties");;
		prop.load(fis);
		log.info("Host information : "+prop.getProperty("HOST_JIRA"));
		RestAssured.baseURI=prop.getProperty("HOST_JIRA");
	}*/
	
	@Test
	public void getLatestTweet()
	{
		RestAssured.baseURI="https://api.twitter.com/1.1/statuses";
		Response res = given()
			.auth().oauth(ConsumerKey, ConsumerSecret, Token, TokenSecret)
			.queryParam("count", 1)
		.when()
			.get(resources.getLatestTweet())
		.then()
			.statusCode(200)
		.extract()
			.response();
		
		String response = res.asString();
		System.out.println(response);
		
		// Removing extra '[' , ']' characters from the JSON string
		response = response.substring(1, response.length()-1);
		System.out.println(response);
		
		JsonPath js = new JsonPath(response);
		String text = js.get("text");
		Long id = js.get("id");
		System.out.println(text);
		System.out.println(id);
		
	}
	
	@Test
	public void createTweet()
	{
		
		RestAssured.baseURI="https://api.twitter.com/1.1/statuses";
		Response res=	given().auth().oauth(ConsumerKey, ConsumerSecret, Token, TokenSecret)
				.queryParam("status", "I am creating this tweet from Automation scripts"+Utilities.generateRandomNumber())
			.when()
				.post(resources.postCreateTweet())
			.then()
				.statusCode(200)
			.extract()
				.response();
	
		String response = res.asString();
		System.out.println(response);
		JsonPath js = new JsonPath(response);
		String text = js.get("text");
		Long id = js.get("id");
		System.out.println(text);
		System.out.println(id);
	
	}
}
